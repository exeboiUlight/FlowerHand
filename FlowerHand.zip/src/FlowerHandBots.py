import socket
import time

class Client:
    def __init__(self, host='127.0.0.1'):
        self.host = host
        self.port = 10000
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    def connect(self):
        self.socket.connect((self.host, self.port))

    def send_message(self, message):
        self.socket.send(message.encode('utf-8'))

    def receive_message(self):
        try:
            data = self.socket.recv(1024).decode('utf-8')
            return data if data else None
        except:
            return None

    def disconnect(self):
        self.socket.close()

class Bot:
    def __init__(self, name="FlowerHandBot", host="127.0.0.1"):
        self.app = Client(host)
        self.app.connect()
        self.app.send_message(f"USERNAME: {name}")
    
    def getMessage(self):
        message = self.app.receive_message()
        username = message.split(":", 1)[0].strip()
        obj = message.split(":", 1)[1].strip()
        return [username, obj]

    def send_message(self, message):
        time.sleep(0.000005)
        self.app.send_message(message)
    
    def off(self):
        self.app.disconnect()